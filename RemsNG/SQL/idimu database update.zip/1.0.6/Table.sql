﻿alter table tbl_demandnotice add wardId uniqueidentifier;
alter table tbl_demandnotice add streetId uniqueidentifier;

