﻿alter table tbl_demandNoticePaymentHistory add syncStatus bit NOT NULL default 0
