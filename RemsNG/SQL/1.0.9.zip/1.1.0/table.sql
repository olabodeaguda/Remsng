﻿alter table tbl_demandnotice add isUnbilled bit;
alter table tbl_demandNoticeTaxpayers add isUnbilled bit;